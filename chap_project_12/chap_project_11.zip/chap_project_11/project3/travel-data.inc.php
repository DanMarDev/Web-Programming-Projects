<?php
  $postId1 = 1;
  $userId1 = 2;
  $userName1 = "Leonie Kohler";
  $date1 = "2/8/2017";
  $thumb1 = "8710320515.jpg";
  $title1 = "Ekklisia Agii Isidori Church";
  $excerpt1 = "At the end of the hot climb up to the top Lycabettus Hill you are greeted with the oasis that is the Ekklisia Agii Isidori church.";
  $reviewsNum1 = 15;
  $reviewsRating1 = 3;
  
  $postId2 = 3;
  $userId2 = 5;
  $userName2 = "Frantisek  Wichterlova";
  $date2 = "9/9/2017";
  $thumb2 = "8710247776.jpg";
  $title2 = "Santorini Sunset";
  $excerpt2 = "Every evening as the sun sets in Fira, it seems that everyone who is not drinking or eating is rushing with their camera to the most picturesque locations in order to capture that famous Aegean sunset.";
  $reviewsNum2 = 38;
  $reviewsRating2 = 5;  

  $postId3 = 9;
  $userId3 = 13;
  $userName3 = "Edward Francis";
  $date3 = "10/19/2017";
  $thumb3 = "8710289254.jpg";
  $title3 = "Looking towards Fira";
  $excerpt3 = "The steamer Mongolia, belonging to the Peninsular and Oriental Company, built of iron, of two thousand eight hundred tons burden, and five hundred horse-power, was due at eleven o'clock a.m. on Wednesday, the 9th of October, at Suez.";  
  $reviewsNum3 = 3;
  $reviewsRating3 = 2;  
  
?>