<?php

$file1 = '0205886159.jpg';
$title1 = 'Global Issues, Local Arguments';
$quantity1 = 25;
$price1 = 25;


$file2 = '0205875548.jpg';
$title2 = 'The Prentice Hall Guide for College Writers';
$quantity2 = 50;
$price2 = 50;


$file3 = '0321826035.jpg';
$title3 = 'Introductory and Intermediate Algebra 5e';
$quantity3 = 40;
$price3 = 35;


$file4 = '0205902278.jpg';
$title4 = 'Literature and the Writing Process';
$quantity4 = 300;
$price4 = 20;

?>
